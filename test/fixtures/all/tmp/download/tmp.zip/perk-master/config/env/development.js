module.exports = {
	build: {
		scripts: {
			loader: 'webpack'
		}
	}
};
