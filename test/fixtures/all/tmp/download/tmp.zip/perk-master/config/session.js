module.exports = {
	secret: 'SECRET_GOES_HERE',
	resave: false,
	saveUninitialized: false
};
