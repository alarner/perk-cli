let express = require('express');
let router = express.Router();

// router.get('/products', function(req, res, next) {

// });

module.exports = router;
